import csv
from pymongo import MongoClient
from datetime import datetime

# 🔗 MongoDB Connection
print("🔌 Connecting to MongoDB...")
client = MongoClient("mongodb+srv://kattamanchimaheshreddy1414:m8OmbSYtb6tkLRG7@cluster0.6roygjo.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
db = client["book_review_platform"]
books_col = db["books"]
reviews_col = db["reviews"]
print("✅ Connected to MongoDB")

# 🧹 Clear previous data (optional)
print("🧹 Clearing old data...")
books_col.delete_many({})
reviews_col.delete_many({})
print("✅ Old data cleared")

# 📄 Read CSV and Upload
print("📄 Reading and uploading CSV...")
try:
    with open("book_reviews.csv", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        count = 0
        for row in reader:
            # 🧾 Add book if not already in DB
            book = books_col.find_one({"book_name": row['book name']})
            if not book:
                book_id = books_col.insert_one({
                    "book_name": row['book name'],
                    "ASIN": row['ASIN']
                }).inserted_id
            else:
                book_id = book["_id"]

            # ✍️ Insert review
            reviews_col.insert_one({
                "book_id": book_id,
                "review_title": row['review title'],
                "reviewer": row['reviewer'],
                "reviewer_rating": float(row['reviewer rating']),
                "review_description": row['review description'],
                "is_verified": row['is_verified'].lower() == 'true',
                "date": row['date'],
                "timestamp": row['timestamp']  # Keeping it as string
            })

            count += 1
            if count % 100 == 0:
                print(f"🔄 {count} reviews inserted...")

    print(f"✅ Upload complete. Total reviews inserted: {count}")

except FileNotFoundError:
    print("❌ Error: 'book_reviews.csv' file not found.")
except Exception as e:
    print("❌ An error occurred:", e)
