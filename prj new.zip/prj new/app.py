# app.py
from flask import Flask, render_template, request, redirect, url_for, session, flash
from pymongo import MongoClient
from bson import ObjectId
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# MongoDB setup
client = MongoClient("mongodb+srv://kattamanchimaheshreddy1414:m8OmbSYtb6tkLRG7@cluster0.6roygjo.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
db = client['book_review_platform']
users_col = db['users']
books_col = db['books']
top_books_col = db['top_books']
reviews_col = db['reviews']

# Home
@app.route('/')
def home():
    if 'email' in session:
        return render_template('search.html')
    return redirect(url_for('login'))

# Register
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        print("Form keys:", request.form.keys())

        name = request.form.get('name', None)
        email = request.form.get('email', None)
        password_raw = request.form.get('password', None)

        if not all([name, email, password_raw]):
            flash("Missing field(s) in form submission.")
            return redirect(url_for('register'))

        password = generate_password_hash(password_raw)

        if users_col.find_one({'email': email}):
            flash("Email already registered")
            return redirect(url_for('register'))

        users_col.insert_one({'name': name, 'email': email, 'password': password})
        flash("Registered successfully. Please login.")
        return redirect(url_for('login'))

    return render_template('register.html')


# Login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        user = users_col.find_one({'email': email})
        if user and check_password_hash(user['password'], password):
            session['email'] = email
            return redirect(url_for('home'))
        flash("Invalid credentials")
    return render_template('login.html')

# Logout
@app.route('/logout')
def logout():
    session.pop('email', None)
    return redirect(url_for('login'))

# Search books
@app.route('/search', methods=['POST'])
def search():
    keyword = request.form['keyword']
    books = books_col.find({'book_name': {'$regex': keyword, '$options': 'i'}})
    return render_template('results.html', books=books)




# View reviews
@app.route('/book/<book_id>', methods=['GET', 'POST'])
def book_reviews(book_id):
    if request.method == 'POST':
        user = users_col.find_one({'email': session['email']})
        reviewer_name = user['name'] if user else "Anonymous"

        reviews_col.insert_one({
            'book_id': ObjectId(book_id),
            'review_title': request.form['title'],
            'reviewer': reviewer_name,
            'reviewer_rating': float(request.form['rating']),
            'review_description': request.form['description'],
            'is_verified': True,
            'date': request.form['date'],
            'timestamp': request.form['date']
        })
        flash("Review added successfully")
        return redirect(url_for('book_reviews', book_id=book_id))

    book = books_col.find_one({'_id': ObjectId(book_id)})
    reviews = list(reviews_col.find({'book_id': ObjectId(book_id)}))
    return render_template('book_reviews.html', book=book, reviews=reviews)



if __name__ == '__main__':
    app.run(debug=True)
